"""Create local secrets once. Standard library only; works on Windows/macOS/Linux."""
from pathlib import Path
import secrets
root=Path(__file__).resolve().parents[1]
env=root/".env"
if env.exists():
    print(".env already exists; preserving your credentials.")
else:
    password=secrets.token_urlsafe(12)
    values={"JWT_SECRET":secrets.token_urlsafe(48),"SERVICE_KEY":secrets.token_urlsafe(48),"MCP_TOKEN":secrets.token_urlsafe(48),"POSTGRES_PASSWORD":secrets.token_urlsafe(24),"RABBIT_PASSWORD":secrets.token_urlsafe(24),"DEMO_PASSWORD":password,"AI_MODE":"demo","FX_MODE":"fixture","MODEL_NAME":"","MODEL_API_KEY":"","MODEL_BASE_URL":"https://generativelanguage.googleapis.com/v1beta/openai"}
    for name in ("IDENTITY","EXPENSE","REVIEW","POLICY","INTEGRATION"):
        values[name+"_DB_PASSWORD"]=secrets.token_urlsafe(24)
    env.write_text("\n".join(f"{k}={v}" for k,v in values.items())+"\n")
    try:env.chmod(0o600)
    except OSError:pass
    print("Created .env. Demo usernames: employee, reviewer, admin")
    print("Demo password:",password)
print("Next: docker compose up --build -d")
print("Open http://localhost:3000")
