"""Verify the real Compose queue path using synthetic reports. Requires project Python dependencies."""
import getpass,json,os,time
from pathlib import Path
import httpx
root=Path(__file__).resolve().parents[1]
password=os.getenv('DEMO_PASSWORD') or getpass.getpass('Demo password: ')
with httpx.Client(base_url=os.getenv('TRIPLEDGER_URL','http://localhost:3000'),timeout=20) as client:
    login=client.post('/api/auth/login',json={'username':'employee','password':password})
    login.raise_for_status();client.headers['Authorization']='Bearer '+login.json()['access_token']
    for name,expected,reimbursable,disallowed in [('clean','auto_approve','420.00','0.00'),('hotel-excess','manager_review','450.00','150.00'),('prohibited','audit_hold','0.00','100.00')]:
        report=json.loads((root/'fixtures/demo'/f'{name}.json').read_text())
        for line in report['line_items']:
            receipt=root/'fixtures/demo'/line.pop('receipt_file')
            with receipt.open('rb') as stream:
                r=client.post('/api/receipts',files={'file':(receipt.name,stream,'application/json')});r.raise_for_status()
                line['receipt_id']=r.json()['receipt_id']
        r=client.post('/api/reports',json=report);r.raise_for_status();report_id=r.json()['report_id']
        r=client.post(f'/api/reports/{report_id}/submit');r.raise_for_status()
        deadline=time.monotonic()+120
        while time.monotonic()<deadline:
            r=client.get('/api/reviews');r.raise_for_status()
            decision=next((d for d in r.json() if d['report_id']==report_id),None)
            if decision:break
            time.sleep(2)
        else:raise SystemExit(f'{name}: review did not complete within 120s. Inspect ai-worker logs and tripledger.dead.')
        assert decision['decision']==expected,decision
        assert decision['reimbursable_total']['amount']==reimbursable,decision
        assert decision['disallowed_total']['amount']==disallowed,decision
        print(f'PASS {name}: {expected}, reimbursable EUR {reimbursable}, disallowed EUR {disallowed}')
print('All three broker-backed smoke scenarios passed.')
