# TripLedger

An expense compliance review workspace built with **Spring Boot microservices, a Python AI/MCP service, React, PostgreSQL and RabbitMQ**. Built for Prerit Jain from the TripLedger case study.

Create expense reports, attach synthetic receipts, reconcile claims against card and travel records, evaluate policy rules, and review findings with an evidence trail. Decisions go to a review queue, never to payroll or a payment system.

## Run locally

Prerequisites: Docker Engine/Desktop with Compose v2, Python 3.11+ for the setup helper, and roughly 6–8 GB of available RAM for the full stack. Java, Maven and Node are installed inside the build containers. Initial image/dependency downloads need internet access.

```sh
python scripts/setup.py
docker compose up --build -d
```

Open **http://localhost:3000** after the containers become healthy. The initial build can take several minutes.

The setup command prints a generated password and saves it as `DEMO_PASSWORD` in `.env`. All three demo accounts use this password:

| Username | Role | What to try |
|---|---|---|
| `employee` | Employee | Create a report, attach receipts, submit |
| `reviewer` | Finance reviewer | Inspect evidence and accept/override findings |
| `admin` | Policy administrator | Create a new immutable policy version |

Credentials are generated locally; no usable keys are included in this source archive. Tokens stay in browser memory and expire after one hour. Reloading the page requires signing in again.

### First walkthrough

1. Sign in as `employee`, click **New report**, and choose **Clean**.
2. Click **Generate synthetic receipt**, then **Save draft**.
3. Click **Submit for review**. The UI polls every five seconds.
4. Open Overview: the clean EUR 420 hotel claim should be automatically cleared.
5. Create **Hotel excess**. A EUR 600 claim for three nights has EUR 150 disallowed and requires manager review.
6. Create **Prohibited**. The synthetic gambling transaction is fully disallowed and held for audit.
7. Sign out and sign in as `reviewer`. Open a decision, inspect the evidence, and record a reason before accepting or overriding a finding.

The default `AI_MODE=demo` is a deterministic, key-free orchestration path. The UI labels the model as `deterministic-demo`. It exercises the same MCP tools, persistence and decision gate as live mode, but **does not call an LLM**.

### Operations

```sh
docker compose ps
docker compose logs -f ai-worker mcp-service
docker compose logs -f expense-service review-service
docker compose down
```

`docker compose down` preserves named volumes. `docker compose down -v` deletes the local demo databases, receipts and traces; use it only when intentionally resetting the demo. Changing `.env` database passwords after first initialization does not change existing PostgreSQL roles; preserve the generated values or deliberately reset the demo volumes.

After the stack is running, `python scripts/smoke_test.py` submits three synthetic reports and checks broker-backed review outcomes (requires the Python package dependencies).

RabbitMQ management is local-only at http://localhost:15672, user `tripledger`, password `RABBIT_PASSWORD` from `.env`. Exhausted jobs are retained in `tripledger.dead` for inspection. No application API sends email or pays money.

## Architecture

```mermaid
flowchart TD
  Web[React] --> Gateway[Spring Cloud Gateway]
  Gateway --> Identity[Identity service]
  Gateway --> Expense[Expense service]
  Gateway --> Review[Review service]
  Gateway --> Policy[Policy service]
  Expense --> Outbox[Transactional outbox]
  Outbox --> Rabbit[RabbitMQ]
  Rabbit --> Worker[Python AI worker]
  Worker --> Model[Optional model API]
  Worker --> MCP[Python MCP service]
  MCP --> Expense
  MCP --> Review
  MCP --> Policy
  MCP --> Integration[Integration service]
  Integration --> Sources[Synthetic upstreams / historical FX]
```

| Component | Source | Ownership |
|---|---|---|
| Gateway | `services/api-gateway` | Routing, JWT verification |
| Identity | `services/identity-service` | Seeded demo accounts, BCrypt passwords, JWT issuance |
| Expense | `services/expense-service` | Reports, receipts, immutable submission, outbox |
| Review | `services/review-service` | Runs, trusted calculations, final decision gate, reviewer actions, audit history, settled-claim input |
| Policy | `services/policy-service` | Immutable policy versions and city/MCC resources |
| Integration | `services/integration-service` | Synthetic card/travel/HR adapters and historical FX cache |
| MCP | `python/tripledger/mcp_server.py` | Nine scoped tools, resources, prompt, calculation boundary |
| AI | `python/tripledger/agent.py` | Demo/live orchestration and traces |
| Worker | `python/tripledger/worker.py` | Durable job consumption and retries |
| Frontend | `web` | Login, overview, reports, review details and policy management |

Each Java business service owns a separate PostgreSQL database and role. There are no cross-database joins. `common` is a compile-time utility library, not a deployed service. Documents use typed ownership/index columns plus JSON text for versioned contracts; this keeps the demonstration small while maintaining ownership boundaries.

Receipt bytes use a service-owned Docker volume. MCP checkpoints use SQLite in its own volume. Replayable AI traces use a separate volume. This implementation is intended for a **single MCP replica**; move checkpoint storage to PostgreSQL and add per-run locking before horizontally scaling it. Object storage is an extension point, not a dependency in this version.

Gateway and business services verify JWTs. Internal endpoints require a separate service key and are not routed through the gateway. Only MCP holds integration service access; the AI worker has a scoped MCP token and no backend credentials. Nginx applies login rate limiting. This is a local educational deployment, not a public production security configuration.

## Python AI and MCP

Nine tools:

```text
get_employee              get_trip
list_card_transactions    list_settled_lines
read_receipt              match_transactions
fx_convert                compute_totals
save_decision
```

Three canonical resources, plus equivalent run-pinned resource templates:

```text
tripledger://policy/expense-policy
tripledger://policy/per-diem
tripledger://reference/mcc-codes

tripledger://policy/expense-policy/{run_id}
tripledger://policy/per-diem/{run_id}
tripledger://reference/mcc-codes/{run_id}
```

Prompt: `review_expense`. Tools resolve the report, employee, receipt ownership, policy snapshot and upstream records on the server. The model cannot provide arbitrary employee IDs, file paths, exchange rates or cap values. Match IDs must come from candidate pairs, and a card transaction cannot be assigned to two lines.

The model receives native tool schemas and chooses its tool sequence in live mode. The application reserves `save_decision` until it has assembled output from a trusted calculation. A twelve-turn limit and token budget stop unbounded agent loops. Budget exhaustion/model errors force confidence to zero and manager review; the code does not silently turn a failed live review into a confident demo result.

### Enable a model

Edit `.env`:

```dotenv
AI_MODE=live
MODEL_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai
MODEL_NAME=your-current-supported-tool-calling-model
MODEL_API_KEY=your-key
```

Then recreate the worker:

```sh
docker compose up -d --force-recreate ai-worker ai-service
```

`providers.py` is the provider boundary. It uses an OpenAI-compatible chat/tool API and supports configurable endpoint/model names. A provider must support native function calling. Obtain the current model name and limits from that provider's official documentation. No paid or live model calls were made during verification; model-specific behavior, quotas and live evaluation must be checked with your key.

### Receipts and privacy

The demo uses structured synthetic JSON receipts. PNG/JPEG/PDF inputs are supported by local Tesseract/Poppler extraction; low-confidence results force review. PDF OCR currently reads the first page only. Raw receipt images are **not** sent to external model APIs. Free-text contacts are redacted before model use and tracing. Only synthetic test data belongs in this project.

### Money and policy behavior

- Python `Decimal`, Java `BigDecimal`, and decimal-string JSON avoid binary floating-point money calculations.
- Base/report currency is EUR in this version; foreign line currencies are converted to EUR.
- Policies are fetched at runtime and pinned at first review. The applicable version is selected by report submission date, effective dates, then version ID as a stable tiebreaker.
- Rules R-01 through R-10 are implemented. Monetary caps, thresholds, grade exceptions and severity defaults are data-driven.
- Historical FX records preserve requested date, returned rate date and source. `FX_MODE=fixture` uses explicitly synthetic rates. Set `FX_MODE=live` for Frankfurter historical rates; weekends can return the preceding published rate. The live FX endpoint has not been exercised in this verification.
- A missing rate produces `null` totals and `complete=false`, never an invented zero or estimated rate. This is an explicit extension of the original case-study schema.
- Suspected duplicates require review. Prohibited merchant categories force `audit_hold`. Other unresolved findings force `manager_review`.
- EUR 25 requires a receipt; EUR 2,500 is conservatively excluded from automatic approval.
- Daily meals are aggregated by date and client/non-client category. Client attendee counts are treated as declarations requiring supporting review when incomplete.
- Overlapping disallowances use the largest applicable restriction for a line, capped at the claimed amount, so a prohibited line is not deducted twice. This is an explicit demo policy interpretation; a richer tax/item allocation policy would require item-level receipt data.
- Human finding overrides are appended with reasons and identity. They preserve the original machine decision and totals; they do not authorize settlement or silently recalculate the claim.

## Run tests

Python:

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -e "./python[test]"
pytest python/tests -q
python -m tripledger.evals
```

Java (JDK 17+ and Maven 3.9+):

```sh
mvn verify
```

Frontend (Node 22+):

```sh
cd web
npm ci
npm run build
```

Run these commands from the project root, except the frontend commands. `evals/reports` contains 25 labelled scenarios covering the ten rules, duplicate detection, injection-like descriptions, missing FX and partial pagination. The harness compares decisions/findings with labels, checks independently labelled expected totals and recomputes accounting identities. These are **offline tooling metrics**, not measured LLM accuracy. See `RESULTS.md` for what was actually tested.

CI runs Java, Python and frontend checks on pushes and pull requests.

## CLI and batch submission

With the stack running and the Python package installed:

```sh
python -m tripledger.cli fixtures/demo/clean.json
python -m tripledger.cli fixtures/demo
```

The CLI prompts for the demo password, uploads referenced local receipts, creates drafts and submits reports. Invalid inputs are reported and do not abort later batch entries. It returns submitted run IDs; the UI shows asynchronous review results. The evaluation fixture format is richer than the intake format, so use `fixtures/demo` for submission and `evals/reports` for offline scoring.

## API overview

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/login` | Public, rate limited at web ingress |
| GET | `/api/auth/me` | Authenticated |
| GET / POST | `/api/reports` | Employee; reviewers can list all |
| GET | `/api/reports/{id}` | Owner or reviewer |
| POST | `/api/reports/{id}/submit` | Owner or reviewer; idempotent |
| POST | `/api/receipts` | Authenticated multipart upload |
| GET | `/api/reviews` | Owner-scoped or finance queue |
| GET | `/api/reviews/runs` | Owner-scoped or finance runs |
| GET | `/api/reviews/{id}` | Owner or reviewer |
| POST | `/api/reviews/{id}/actions` | Finance reviewer; reason required |
| GET | `/api/reviews/{id}/audit` | Owner or reviewer |
| GET / POST | `/api/policies` | Read authenticated; write policy admin |

Each business service includes Springdoc at `/swagger-ui.html` and `/v3/api-docs` on its private port. The public gateway intentionally exposes business routes only. A local developer can temporarily map a service port for Swagger access. Python operational health runs on internal port 8000. MCP runs on internal port 8001 at `/mcp` and requires its bearer token.

## Scope and remaining extensions

Implemented as an end-to-end educational MVP. It includes executable services rather than placeholder controllers. The following are intentionally not represented as finished production features:

- Real corporate card, travel and HR integrations: synthetic adapters are included, with 20-record pagination.
- Live LLM quality/latency/cost calibration and provider-specific compatibility verification.
- Automated settlement history ingestion from a real ledger. The review service owns the read model and the duplicate engine supports it; demo settled history is empty unless seeded for tests. It never fabricates a settled record from an approval.
- Registration, password recovery, SSO, key rotation and granular multi-tenant authorization.
- Multi-page/high-confidence OCR, real receipts, financial accounting/tax rules or production policy interpretation.
- Production cloud deployment, object storage, distributed tracing export, per-run distributed locks and comprehensive operational alerting.

The Docker Compose configuration is included. Where Docker was unavailable during development, services were tested directly against temporary PostgreSQL and real MCP/HTTP transports; consult `RESULTS.md` for exact verification boundaries.

Official references: [Spring Security JWT](https://docs.spring.io/spring-security/reference/servlet/oauth2/resource-server/jwt.html), [MCP Python SDK v1](https://py.sdk.modelcontextprotocol.io/v1/), [FastAPI](https://fastapi.tiangolo.com/), [Gemini OpenAI compatibility](https://ai.google.dev/gemini-api/docs/openai), [Frankfurter](https://frankfurter.dev/).
