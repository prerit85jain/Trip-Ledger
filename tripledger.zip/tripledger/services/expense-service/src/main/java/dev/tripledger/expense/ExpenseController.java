package dev.tripledger.expense;
import dev.tripledger.common.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.multipart.MultipartFile;
import java.nio.file.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
@RestController
public class ExpenseController {
 private final Store store; private final Path root=Path.of(System.getenv().getOrDefault("RECEIPT_DIR","/data/receipts"));
 public ExpenseController(Store s){store=s;}
 @GetMapping("/api/reports") public List<JsonNode> list(@AuthenticationPrincipal Jwt jwt){return store.list("report",Access.role(jwt,"FINANCE_REVIEWER")?null:jwt.getClaimAsString("employee_id"));}
 @GetMapping("/api/reports/{id}") public JsonNode get(@PathVariable String id,@AuthenticationPrincipal Jwt jwt){var r=store.get(id);Access.owner(jwt,r.path("employee_id").asText());return r;}
 @PostMapping("/api/reports") @ResponseStatus(HttpStatus.CREATED) @Transactional
 public JsonNode create(@RequestBody JsonNode input,@AuthenticationPrincipal Jwt jwt){
  if(!input.isObject())throw new IllegalArgumentException("Report must be an object");
  var b=(ObjectNode)Redaction.clean(input);String employee=jwt.getClaimAsString("employee_id");
  Json.required(b,"trip_id");String ccy=Json.required(b,"base_currency");if(!ccy.equals("EUR"))throw new IllegalArgumentException("Invalid currency");
  var lines=b.path("line_items");if(!lines.isArray()||lines.isEmpty()||lines.size()>100)throw new IllegalArgumentException("Provide 1 to 100 line items");
  Set<String> ids=new HashSet<>();for(var l:lines){String id=Json.required(l,"line_id");if(!ids.add(id))throw new IllegalArgumentException("Duplicate line_id");LocalDate.parse(Json.required(l,"date"));Json.required(l,"merchant");if(!List.of("hotel","meals","taxi","flight","other").contains(Json.required(l,"category")))throw new IllegalArgumentException("Invalid category");if(!Json.required(l,"currency").matches("[A-Z]{3}"))throw new IllegalArgumentException("Invalid line currency");var amount=new BigDecimal(Json.required(l,"amount"));if(amount.signum()<0||amount.scale()>2||amount.compareTo(new BigDecimal("1000000"))>0)throw new IllegalArgumentException("Invalid amount; use a decimal string with at most 2 places");for(String optional:List.of("nights","attendees")){if(l.hasNonNull(optional)&&(!l.get(optional).canConvertToInt()||l.get(optional).asInt()<1||l.get(optional).asInt()>1000))throw new IllegalArgumentException("Invalid "+optional);}if(l.hasNonNull("alcohol_amount")&&new BigDecimal(l.get("alcohol_amount").asText()).signum()<0)throw new IllegalArgumentException("Negative alcohol amount");String receipt=l.path("receipt_id").asText("");if(!receipt.isBlank()){var rec=store.get(receipt);if(!employee.equals(rec.path("employee_id").asText()))throw new ResponseStatusException(HttpStatus.FORBIDDEN);}}
  String id="EXP-"+UUID.randomUUID().toString().substring(0,12);b.put("report_id",id).put("employee_id",employee).put("revision",1).put("status","DRAFT").put("submitted_at",Instant.now().toString());store.insert(id,"report",employee,b);return b;
 }
 @PostMapping("/api/reports/{id}/submit") @Transactional public JsonNode submit(@PathVariable String id,@AuthenticationPrincipal Jwt jwt){
  store.jdbc.queryForObject("SELECT id FROM documents WHERE id=? FOR UPDATE",String.class,id);var b=(ObjectNode)get(id,jwt);if(!b.path("status").asText().equals("DRAFT"))return b;
  b.put("status","SUBMITTED").put("submitted_at",Instant.now().toString());String run=id+"-r1";b.put("run_id",run);store.put(id,"report",b.path("employee_id").asText(),b);
  var event=Json.obj().put("event_id",run).put("run_id",run).put("event_type","ExpenseReportSubmitted").set("report",b);store.jdbc.update("INSERT INTO outbox(id,body) VALUES(?,?)",run,Json.write(event));store.audit(jwt.getSubject(),id,"SUBMITTED",Json.obj().put("run_id",run));return b;
 }
 @PostMapping(value="/api/receipts",consumes=MediaType.MULTIPART_FORM_DATA_VALUE) public JsonNode upload(@RequestParam MultipartFile file,@AuthenticationPrincipal Jwt jwt)throws Exception {
  String type=Objects.toString(file.getContentType(),"");if(!List.of("application/json","image/png","image/jpeg","application/pdf").contains(type))throw new IllegalArgumentException("Use JSON, PNG, JPEG or PDF");
  byte[] bytes=file.getBytes();if(bytes.length==0||bytes.length>8*1024*1024)throw new IllegalArgumentException("Receipt must be 1 byte to 8 MB");
  if(type.equals("application/json")){var clean=Redaction.clean(Json.read(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)));bytes=Json.write(clean).getBytes(java.nio.charset.StandardCharsets.UTF_8);}
  String id="RCT-"+UUID.randomUUID();Files.createDirectories(root);Files.write(root.resolve(id),bytes,StandardOpenOption.CREATE_NEW);var meta=Json.obj().put("receipt_id",id).put("employee_id",jwt.getClaimAsString("employee_id")).put("media_type",type).put("size",bytes.length);store.insert(id,"receipt",jwt.getClaimAsString("employee_id"),meta);return meta;
 }
 @GetMapping("/internal/reports/{id}") public JsonNode internal(@PathVariable String id){return store.get(id);}
 @GetMapping("/internal/receipts/{id}") public JsonNode receiptMeta(@PathVariable String id){return store.get(id);}
 @GetMapping("/internal/receipts/{id}/content") public ResponseEntity<byte[]> receipt(@PathVariable String id)throws Exception {var meta=store.get(id);if(!id.matches("RCT-[a-f0-9-]+"))throw new IllegalArgumentException("Invalid receipt id");return ResponseEntity.ok().contentType(MediaType.parseMediaType(meta.path("media_type").asText())).body(Files.readAllBytes(root.resolve(id)));}
}
