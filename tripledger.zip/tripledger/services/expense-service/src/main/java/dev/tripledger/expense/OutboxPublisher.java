package dev.tripledger.expense;
import dev.tripledger.common.*;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Bean;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.scheduling.annotation.Scheduled;
import java.util.concurrent.TimeUnit;
@Component
public class OutboxPublisher {
 private final Store store;private final RabbitTemplate rabbit;
 public OutboxPublisher(Store s,RabbitTemplate r){store=s;rabbit=r;}
 @Bean Queue queue(){return QueueBuilder.durable("tripledger.reviews").withArgument("x-dead-letter-exchange","").withArgument("x-dead-letter-routing-key","tripledger.dead").build();}
 @Bean Queue dead(){return QueueBuilder.durable("tripledger.dead").build();}
 @Scheduled(fixedDelay=3000) public void publish(){
  var rows=store.jdbc.queryForList("SELECT id,body FROM outbox WHERE sent=FALSE ORDER BY created_at LIMIT 20");
  for(var row:rows){try{String id=(String)row.get("id");var data=new CorrelationData(id);var message=MessageBuilder.withBody(((String)row.get("body")).getBytes(java.nio.charset.StandardCharsets.UTF_8)).setContentType("application/json").setDeliveryMode(MessageDeliveryMode.PERSISTENT).setMessageId(id).build();rabbit.send("","tripledger.reviews",message,data);if(data.getFuture().get(10,TimeUnit.SECONDS).isAck())store.jdbc.update("UPDATE outbox SET sent=TRUE WHERE id=?",id);}catch(Exception e){System.err.println("Outbox delivery deferred: "+e.getClass().getSimpleName());return;}}
 }
}
