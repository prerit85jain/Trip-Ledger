package dev.tripledger.gateway;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.context.annotation.Bean;
import org.springframework.cloud.gateway.route.*;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
@SpringBootApplication
public class Application {
 public static void main(String[] a){SpringApplication.run(Application.class,a);}
 @Bean RouteLocator routes(RouteLocatorBuilder b){return b.routes()
 .route("identity",r->r.path("/api/auth/**").uri(System.getenv().getOrDefault("IDENTITY_URL","http://identity-service:8081")))
 .route("expenses",r->r.path("/api/reports","/api/reports/**","/api/receipts","/api/receipts/**").uri(System.getenv().getOrDefault("EXPENSE_URL","http://expense-service:8082")))
 .route("reviews",r->r.path("/api/reviews","/api/reviews/**").uri(System.getenv().getOrDefault("REVIEW_URL","http://review-service:8083")))
 .route("policy",r->r.path("/api/policies","/api/policies/**").uri(System.getenv().getOrDefault("POLICY_URL","http://policy-service:8084"))).build();}
}
