package dev.tripledger.gateway;
import org.springframework.context.annotation.*;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.oauth2.jwt.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
@Configuration
public class GatewaySecurity {
 @Bean ReactiveJwtDecoder decoder(){String secret=System.getenv("JWT_SECRET");if(secret==null||secret.length()<32)throw new IllegalStateException("JWT_SECRET required");var d=NimbusReactiveJwtDecoder.withSecretKey(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256")).build();d.setJwtValidator(JwtValidators.createDefaultWithIssuer("tripledger"));return d;}
 @Bean SecurityWebFilterChain filter(ServerHttpSecurity h){return h.csrf(c->c.disable()).authorizeExchange(a->a.pathMatchers("/api/auth/login","/actuator/health").permitAll().anyExchange().authenticated()).oauth2ResourceServer(o->o.jwt(j->{})).build();}
}
