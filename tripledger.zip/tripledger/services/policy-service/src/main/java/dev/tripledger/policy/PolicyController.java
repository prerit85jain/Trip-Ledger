package dev.tripledger.policy;
import dev.tripledger.common.*;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;
@RestController
public class PolicyController {
 private final Store store;public PolicyController(Store s){store=s;}
 @Bean ApplicationRunner seed(){return a->{if(!store.exists("2026-Q2")){var b=Json.read(new String(new ClassPathResource("policy.json").getInputStream().readAllBytes()));store.insert("2026-Q2","policy","system",b);}};}
 @GetMapping({"/api/policies","/internal/policies"}) public List<JsonNode> list(){return store.list("policy",null);}
 @GetMapping({"/api/policies/{version}","/internal/policies/{version}"}) public JsonNode get(@PathVariable String version){return store.get(version);}
 @PostMapping("/api/policies") @ResponseStatus(HttpStatus.CREATED) public JsonNode create(@RequestBody JsonNode p,@AuthenticationPrincipal Jwt jwt){if(!Access.role(jwt,"POLICY_ADMIN"))throw new ResponseStatusException(HttpStatus.FORBIDDEN);String v=Json.required(p,"version");if(!v.matches("[A-Za-z0-9._-]{1,40}"))throw new IllegalArgumentException("Invalid version");for(String field:List.of("receipt_threshold","auto_approval_ceiling","confidence_threshold","per_diem","rules","effective_from","effective_to","mcc"))if(!p.has(field))throw new IllegalArgumentException("Missing "+field);java.time.LocalDate.parse(p.get("effective_from").asText());java.time.LocalDate.parse(p.get("effective_to").asText());store.insert(v,"policy",jwt.getSubject(),p);store.audit(jwt.getSubject(),v,"POLICY_CREATED",Json.obj().put("version",v));return p;}
}
