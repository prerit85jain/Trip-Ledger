package dev.tripledger.integration;
import dev.tripledger.common.*;
import com.fasterxml.jackson.databind.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.client.RestClient;
import java.time.LocalDate;
import java.util.*;
@RestController
public class IntegrationController {
 private final JsonNode fixtures;private final Store store;
 public IntegrationController(Store s)throws Exception{store=s;fixtures=Json.read(new String(new ClassPathResource("fixtures.json").getInputStream().readAllBytes()));}
 @GetMapping("/internal/employees/{id}") public JsonNode employee(@PathVariable String id){if(!fixtures.path("employees").has(id))throw new IllegalArgumentException("Unknown employee");return fixtures.path("employees").get(id);}
 @GetMapping("/internal/trips/{id}") public JsonNode trip(@PathVariable String id){if(!fixtures.path("trips").has(id))throw new IllegalArgumentException("Unknown trip");return fixtures.path("trips").get(id);}
 @GetMapping("/internal/transactions") public JsonNode transactions(@RequestParam String employee_id,@RequestParam String from,@RequestParam String to,@RequestParam(defaultValue="0") int cursor){
  if(cursor<0)throw new IllegalArgumentException("Invalid cursor");LocalDate start=LocalDate.parse(from),end=LocalDate.parse(to);var all=new ArrayList<JsonNode>();for(var t:fixtures.path("transactions")){LocalDate d=LocalDate.parse(t.path("date").asText());if(t.path("employee_id").asText().equals(employee_id)&&!d.isBefore(start)&&!d.isAfter(end))all.add(t);}var page=Json.arr();for(int i=cursor;i<Math.min(cursor+20,all.size());i++)page.add(all.get(i));var result=Json.obj();result.set("items",page);if(cursor+20<all.size())result.put("next_cursor",cursor+20);else result.putNull("next_cursor");return result;
 }
 @GetMapping("/internal/fx") public JsonNode fx(@RequestParam String from,@RequestParam String to,@RequestParam String date){
  if(!from.matches("[A-Z]{3}")||!to.matches("[A-Z]{3}"))throw new IllegalArgumentException("Invalid currency");LocalDate.parse(date);if(from.equals(to))return Json.obj().put("rate","1").put("rate_date",date).put("source","identity");
  String key="FX-"+from+"-"+to+"-"+date;if(store.exists(key))return store.get(key);
  if(System.getenv().getOrDefault("FX_MODE","fixture").equals("fixture")){var rates=fixtures.path("fx").path(date);if(!rates.has(from)||!rates.has(to))throw new IllegalArgumentException("No fixture FX rate for this date");var rate=new java.math.BigDecimal(rates.get(to).asText()).divide(new java.math.BigDecimal(rates.get(from).asText()),12,java.math.RoundingMode.HALF_UP);return Json.obj().put("rate",rate.toPlainString()).put("rate_date",date).put("source","synthetic-fixture");}
  var factory=new org.springframework.http.client.JdkClientHttpRequestFactory();factory.setReadTimeout(java.time.Duration.ofSeconds(8));var client=RestClient.builder().requestFactory(factory).build();var data=client.get().uri("https://api.frankfurter.dev/v1/"+date+"?base="+from+"&symbols="+to).retrieve().body(JsonNode.class);if(data==null||!data.path("rates").has(to))throw new IllegalArgumentException("FX unavailable");var result=Json.obj().put("rate",data.path("rates").get(to).asText()).put("rate_date",data.path("date").asText()).put("requested_date",date).put("source","Frankfurter");store.put(key,"fx","system",result);return result;
 }
}
