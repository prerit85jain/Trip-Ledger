package dev.tripledger.review;
import dev.tripledger.common.*;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class ReviewControllerTest {
 @Test void rejectsTamperedTotals(){var store=new Store(mock(JdbcTemplate.class));var spy=spy(store);doReturn(false).when(spy).exists("DEC-EXP-1-r1");doReturn(Json.read("{\"report_id\":\"EXP-1\",\"employee_id\":\"EMP-001\"}")).when(spy).get("EXP-1-r1");doReturn(Json.read("{\"run_id\":\"EXP-1-r1\",\"reimbursable_total\":{\"amount\":\"18.00\",\"currency\":\"EUR\"}}")).when(spy).get("CALC-1");var c=new ReviewController(spy);assertThrows(IllegalArgumentException.class,()->c.save(Json.read("{\"run_id\":\"EXP-1-r1\",\"calculation_id\":\"CALC-1\",\"reimbursable_total\":{\"amount\":\"999.00\",\"currency\":\"EUR\"}}")));}
}
