package dev.tripledger.review;
import dev.tripledger.common.Json;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class DecisionGateTest {
 ObjectNode clean(){return (ObjectNode)Json.read("{\"complete\":true,\"confidence_cap\":\"0.95\",\"confidence_threshold\":\"0.85\",\"auto_approval_ceiling\":\"2500.00\",\"reimbursable_total\":{\"amount\":\"18.00\"},\"findings\":[]}");}
 @Test void cleanApproves(){assertEquals("auto_approve",DecisionGate.outcome(clean(),.9));}
 @Test void incompleteNeverApproves(){assertEquals("manager_review",DecisionGate.outcome(clean().put("complete",false),1));}
 @Test void boundaryRequiresReview(){var c=clean();((ObjectNode)c.get("reimbursable_total")).put("amount","2500.00");assertEquals("manager_review",DecisionGate.outcome(c,1));}
 @Test void missingTotalRequiresReview(){var c=clean();((ObjectNode)c.get("reimbursable_total")).putNull("amount");assertEquals("manager_review",DecisionGate.outcome(c,1));}
 @Test void duplicateAlwaysEscalates(){var c=clean();c.withArray("findings").add(Json.obj().put("rule_id","R-08").put("severity","advisory"));assertEquals("manager_review",DecisionGate.outcome(c,1));}
 @Test void confidenceCannotBeInvented(){assertEquals("manager_review",DecisionGate.outcome(clean().put("confidence_cap","0.5"),1));assertEquals("manager_review",DecisionGate.outcome(clean(),Double.NaN));}
 @Test void prohibitedHolds(){assertEquals("audit_hold",DecisionGate.outcome(clean().put("audit_required",true),.9));}
}
