package dev.tripledger.review;
import dev.tripledger.common.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
@RestController
public class ReviewController {
 private final Store store;public ReviewController(Store s){store=s;}
 @PostMapping("/internal/runs") @Transactional public JsonNode run(@RequestBody JsonNode b){String id=Json.required(b,"run_id");if(!store.exists(id))store.insert(id,"run",Json.required(b,"employee_id"),b);return store.get(id);}
 @GetMapping("/internal/runs/{id}") public JsonNode run(@PathVariable String id){return store.get(id);}
 @PostMapping("/internal/calculations") public JsonNode calculation(@RequestBody JsonNode b){String id=Json.required(b,"calculation_id");store.insert(id,"calculation",Json.required(b,"run_id"),b);return b;}
 @PostMapping("/internal/decisions") @Transactional public JsonNode save(@RequestBody JsonNode input){
  String run=Json.required(input,"run_id");store.jdbc.queryForObject("SELECT id FROM documents WHERE id=? FOR UPDATE",String.class,run);String id="DEC-"+run;if(store.exists(id))return store.get(id);
  var r=store.get(run);var calc=store.get(Json.required(input,"calculation_id"));if(!run.equals(calc.path("run_id").asText()))throw new IllegalArgumentException("Calculation/run mismatch");
  for(String key:List.of("reimbursable_total","disallowed_total","findings","reconciliation"))if(!calc.path(key).equals(input.path(key)))throw new IllegalArgumentException("Unverified "+key);
  var decision=(ObjectNode)calc.deepCopy();double requested=input.path("confidence").asDouble(0);double confidence=DecisionGate.confidence(calc,requested);String outcome=DecisionGate.outcome(calc,requested);
  decision.put("decision_id",id).put("decision",outcome).put("confidence",confidence).put("report_id",r.path("report_id").asText()).put("employee_id",r.path("employee_id").asText()).put("review_status","OPEN").put("created_at",Instant.now().toString());
  decision.put("draft_query_to_submitter",Redaction.text(input.path("draft_query_to_submitter").asText("")));decision.set("meta",Redaction.clean(input.path("meta")));store.insert(id,"decision",r.path("employee_id").asText(),decision);store.audit("system",id,"DECISION_QUEUED",Json.obj().put("decision",outcome));((ObjectNode)r).put("status","COMPLETED").put("decision_id",id);store.put(run,"run",r.path("employee_id").asText(),r);return decision;
 }
 @PostMapping("/internal/runs/{id}/failure") public JsonNode failed(@PathVariable String id,@RequestBody JsonNode error){var r=(ObjectNode)store.get(id);r.put("status","FAILED").put("error",error.path("code").asText("REVIEW_FAILED"));store.put(id,"run",r.path("employee_id").asText(),r);return r;}
 @GetMapping("/api/reviews") public List<JsonNode> list(@AuthenticationPrincipal Jwt j){var result=new ArrayList<>(store.list("decision",Access.role(j,"FINANCE_REVIEWER")?null:j.getClaimAsString("employee_id")));result.sort((a,b)->amount(b).compareTo(amount(a)));return result;}
 private BigDecimal amount(JsonNode n){return new BigDecimal(n.path("disallowed_total").path("amount").asText("0"));}
 @GetMapping("/api/reviews/runs") public List<JsonNode> runs(@AuthenticationPrincipal Jwt j){return store.list("run",Access.role(j,"FINANCE_REVIEWER")?null:j.getClaimAsString("employee_id"));}
 @GetMapping("/api/reviews/{id}") public JsonNode get(@PathVariable String id,@AuthenticationPrincipal Jwt j){var d=store.get(id);Access.owner(j,d.path("employee_id").asText());return d;}
 @GetMapping("/api/reviews/{id}/audit") public List<JsonNode> audit(@PathVariable String id,@AuthenticationPrincipal Jwt j){get(id,j);return store.audit(id);}
 @PostMapping("/api/reviews/{id}/actions") @Transactional public JsonNode action(@PathVariable String id,@RequestBody JsonNode body,@AuthenticationPrincipal Jwt j){
  Access.reviewer(j);store.jdbc.queryForObject("SELECT id FROM documents WHERE id=? FOR UPDATE",String.class,id);var d=(ObjectNode)get(id,j);String action=Json.required(body,"action"),reason=Json.required(body,"reason");if(!List.of("ACCEPT","OVERRIDE").contains(action))throw new IllegalArgumentException("Invalid action");String fid=Json.required(body,"finding_id");boolean found=false;for(var f:d.path("findings"))if(fid.equals(f.path("finding_id").asText()))found=true;if(!found)throw new IllegalArgumentException("Finding not found");var actionData=Json.obj().put("finding_id",fid).put("action",action).put("reason",Redaction.text(reason)).put("reviewer",j.getSubject()).put("created_at",Instant.now().toString());var actions=d.withArray("reviewer_actions");actions.add(actionData);d.put("review_status","REVIEWED");store.put(id,"decision",d.path("employee_id").asText(),d);store.audit(j.getSubject(),id,action,actionData);return d;
 }
 @GetMapping("/internal/settled-lines") public List<JsonNode> settled(@RequestParam String employee_id,@RequestParam(defaultValue="12") int months){if(months<1||months>12)throw new IllegalArgumentException("months must be 1..12");return store.list("settled",employee_id);}
}
