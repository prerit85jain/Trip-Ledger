package dev.tripledger.review;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.util.Set;
/** Domain gate: model recommendations cannot bypass required checks. */
public final class DecisionGate {
 private static final Set<String> FORCED_REVIEW=Set.of("R-02","R-07","R-08");
 public static double confidence(JsonNode calculation,double requested){
  if(!Double.isFinite(requested))return 0;
  return Math.max(0,Math.min(requested,calculation.path("confidence_cap").asDouble(0)));
 }
 public static String outcome(JsonNode calculation,double requested){
  if(calculation.path("audit_required").asBoolean())return "audit_hold";
  boolean unresolved=false;
  for(var finding:calculation.path("findings")){
   if(Set.of("query","blocking").contains(finding.path("severity").asText())||FORCED_REVIEW.contains(finding.path("rule_id").asText()))unresolved=true;
  }
  if(!calculation.path("complete").asBoolean()||unresolved||confidence(calculation,requested)<calculation.path("confidence_threshold").asDouble(.85))return "manager_review";
  var amount=calculation.path("reimbursable_total").path("amount");
  if(amount.isMissingNode()||amount.isNull())return "manager_review";
  return new BigDecimal(amount.asText()).compareTo(new BigDecimal(calculation.path("auto_approval_ceiling").asText()))<0?"auto_approve":"manager_review";
 }
}
