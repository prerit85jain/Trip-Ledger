package dev.tripledger.identity;
import dev.tripledger.common.*;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import com.nimbusds.jose.jwk.source.ImmutableSecret;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.time.Instant;
import java.nio.charset.StandardCharsets;
import java.util.*;
@RestController
public class AuthController {
 private final Store store;private final BCryptPasswordEncoder passwords=new BCryptPasswordEncoder();
 public AuthController(Store s){store=s;}
 @Bean ApplicationRunner seed(){return args->{String pw=System.getenv("DEMO_PASSWORD");if(pw==null||pw.length()<10)throw new IllegalStateException("Set DEMO_PASSWORD (10+ chars)");for(String user:List.of("employee","reviewer","admin")){if(!store.exists(user))store.insert(user,"user",user,Json.obj().put("username",user).put("password_hash",passwords.encode(pw)).put("employee_id","EMP-001").put("role",user.equals("employee")?"EMPLOYEE":user.equals("reviewer")?"FINANCE_REVIEWER":"POLICY_ADMIN"));}};}
 @PostMapping("/api/auth/login") public Map<String,Object> login(@RequestBody JsonNode body){String user=body.path("username").asText();if(!store.exists(user))throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid credentials");var u=store.get(user);if(!passwords.matches(body.path("password").asText(),u.path("password_hash").asText()))throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid credentials");var now=Instant.now();var claims=JwtClaimsSet.builder().issuer("tripledger").subject(user).issuedAt(now).expiresAt(now.plusSeconds(3600)).claim("employee_id",u.path("employee_id").asText()).claim("roles",List.of(u.path("role").asText())).build();var encoder=new NimbusJwtEncoder(new ImmutableSecret<>(Security.env("JWT_SECRET").getBytes(StandardCharsets.UTF_8)));String token=encoder.encode(JwtEncoderParameters.from(JwsHeader.with(MacAlgorithm.HS256).build(),claims)).getTokenValue();return Map.of("access_token",token,"token_type","Bearer","expires_in",3600,"username",user,"role",u.path("role").asText(),"employee_id",u.path("employee_id").asText());}
 @GetMapping("/api/auth/me") public Map<String,Object> me(@AuthenticationPrincipal Jwt jwt){return Map.of("username",jwt.getSubject(),"employee_id",jwt.getClaimAsString("employee_id"),"roles",jwt.getClaimAsStringList("roles"));}
}
