package dev.tripledger.common;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class RedactionTest {
 @Test void preservesMachineIdentifiers(){String id="RCT-12345678-1234-1234-abcd-123456789abc";assertEquals(id,Redaction.text(id));}
 @Test void protectsContactsAndDates(){assertEquals("2026-10-02",Redaction.text("2026-10-02"));assertEquals("2026-10-03T12:00:00Z",Redaction.text("2026-10-03T12:00:00Z"));assertEquals("****1234",Redaction.text("4".repeat(12)+"1234"));assertFalse(Redaction.text("person@example.test").contains("example.test"));}
}
