package dev.tripledger.common;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;
@Component
public class Store {
 public final JdbcTemplate jdbc;
 public Store(JdbcTemplate j){jdbc=j;}
 public JsonNode get(String id){var r=jdbc.query("SELECT body FROM documents WHERE id=?",(rs,n)->Json.read(rs.getString(1)),id);if(r.isEmpty())throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");return r.get(0);}
 public boolean exists(String id){return Boolean.TRUE.equals(jdbc.queryForObject("SELECT COUNT(*)>0 FROM documents WHERE id=?",Boolean.class,id));}
 public void insert(String id,String kind,String owner,JsonNode body){jdbc.update("INSERT INTO documents(id,kind,owner_id,body) VALUES(?,?,?,?)",id,kind,owner,Json.write(body));}
 public void put(String id,String kind,String owner,JsonNode body){jdbc.update("INSERT INTO documents(id,kind,owner_id,body) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=EXCLUDED.body",id,kind,owner,Json.write(body));}
 public List<JsonNode> list(String kind,String owner){return owner==null?jdbc.query("SELECT body FROM documents WHERE kind=? ORDER BY created_at DESC",(r,n)->Json.read(r.getString(1)),kind):jdbc.query("SELECT body FROM documents WHERE kind=? AND owner_id=? ORDER BY created_at DESC",(r,n)->Json.read(r.getString(1)),kind,owner);}
 public void audit(String actor,String id,String action,JsonNode body){jdbc.update("INSERT INTO audit_events(actor,entity_id,action,body) VALUES(?,?,?,?)",actor,id,action,Json.write(body));}
 public List<JsonNode> audit(String id){return jdbc.query("SELECT actor,action,body,created_at FROM audit_events WHERE entity_id=? ORDER BY id",(r,n)->Json.obj().put("actor",r.getString(1)).put("action",r.getString(2)).put("created_at",r.getString(4)).set("detail",Json.read(r.getString(3))),id);}
}
