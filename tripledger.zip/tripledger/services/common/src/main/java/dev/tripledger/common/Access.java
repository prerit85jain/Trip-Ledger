package dev.tripledger.common;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
public final class Access {
 public static boolean role(Jwt j,String r){return j.getClaimAsStringList("roles").contains(r);}
 public static void reviewer(Jwt j){if(!role(j,"FINANCE_REVIEWER"))throw new ResponseStatusException(HttpStatus.FORBIDDEN);}
 public static void owner(Jwt j,String employee){if(!employee.equals(j.getClaimAsString("employee_id"))&&!role(j,"FINANCE_REVIEWER"))throw new ResponseStatusException(HttpStatus.FORBIDDEN);}
}
