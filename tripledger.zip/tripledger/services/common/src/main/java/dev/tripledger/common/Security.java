package dev.tripledger.common;
import org.springframework.context.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
@Configuration
public class Security {
 public static String env(String key){String v=System.getenv(key);if(v==null||v.length()<32)throw new IllegalStateException(key+" must contain at least 32 characters");return v;}
 @Bean JwtDecoder decoder(){var d=NimbusJwtDecoder.withSecretKey(new SecretKeySpec(env("JWT_SECRET").getBytes(StandardCharsets.UTF_8),"HmacSHA256")).macAlgorithm(MacAlgorithm.HS256).build();d.setJwtValidator(JwtValidators.createDefaultWithIssuer("tripledger"));return d;}
 @Bean @Order(1) SecurityFilterChain internal(HttpSecurity h)throws Exception {
  h.securityMatcher("/internal/**").csrf(c->c.disable()).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS)).authorizeHttpRequests(a->a.anyRequest().permitAll());
  h.addFilterBefore(new OncePerRequestFilter(){protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{String v=req.getHeader("X-Service-Key");if(v==null||!MessageDigest.isEqual(v.getBytes(StandardCharsets.UTF_8),env("SERVICE_KEY").getBytes(StandardCharsets.UTF_8))){res.sendError(401);return;}chain.doFilter(req,res);}},UsernamePasswordAuthenticationFilter.class);return h.build();
 }
 @Bean @Order(2) SecurityFilterChain api(HttpSecurity h)throws Exception {
  var grants=new JwtGrantedAuthoritiesConverter();grants.setAuthoritiesClaimName("roles");grants.setAuthorityPrefix("ROLE_");var converter=new JwtAuthenticationConverter();converter.setJwtGrantedAuthoritiesConverter(grants);
  h.csrf(c->c.disable()).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS)).authorizeHttpRequests(a->a.requestMatchers("/actuator/health","/api/auth/login","/v3/api-docs/**","/swagger-ui/**","/swagger-ui.html").permitAll().anyRequest().authenticated()).oauth2ResourceServer(o->o.jwt(j->j.jwtAuthenticationConverter(converter)));return h.build();
 }
}
