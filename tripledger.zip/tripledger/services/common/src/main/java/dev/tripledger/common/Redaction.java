package dev.tripledger.common;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.*;
import java.util.regex.Pattern;
public final class Redaction {
 public static String text(String s){
  if(s.matches("-?[0-9]+\\.[0-9]+"))return s;
  s=s.replaceAll("(?<![A-Za-z0-9-])(?:[0-9][ -]?){9,15}([0-9]{4})(?![A-Za-z0-9-])","****$1").replaceAll("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}","[email redacted]");
  return Pattern.compile("(?<![A-Za-z0-9-])[+]?[0-9][0-9 ()-]{8,}[0-9](?![A-Za-z0-9-])").matcher(s).replaceAll(m->m.group().matches("20[0-9]{2}-[0-9]{2}-[0-9]{2}")?m.group():"[phone redacted]");
 }
 public static JsonNode clean(JsonNode n){if(n.isTextual())return new TextNode(text(n.asText()));if(n.isArray()){var a=Json.arr();n.forEach(v->a.add(clean(v)));return a;}if(n.isObject()){var o=Json.obj();n.fields().forEachRemaining(e->o.set(e.getKey(),clean(e.getValue())));return o;}return n;}
}
