package dev.tripledger.common;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.dao.DuplicateKeyException;
import java.util.Map;
@RestControllerAdvice
public class Errors {
 @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<?> invalid(IllegalArgumentException e){return ResponseEntity.badRequest().body(Map.of("error",e.getMessage()));}
 @ExceptionHandler(java.time.DateTimeException.class) ResponseEntity<?> date(){return ResponseEntity.badRequest().body(Map.of("error","Invalid ISO date"));}
 @ExceptionHandler(DuplicateKeyException.class) ResponseEntity<?> duplicate(){return ResponseEntity.status(409).body(Map.of("error","This record already exists"));}
}
