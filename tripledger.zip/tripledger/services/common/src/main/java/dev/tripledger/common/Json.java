package dev.tripledger.common;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
public final class Json {
 public static final ObjectMapper M=new ObjectMapper().findAndRegisterModules();
 public static JsonNode read(String s){try{return M.readTree(s);}catch(Exception e){throw new IllegalArgumentException("Invalid JSON");}}
 public static String write(Object o){try{return M.writeValueAsString(o);}catch(Exception e){throw new IllegalArgumentException("Invalid data");}}
 public static ObjectNode obj(){return M.createObjectNode();}
 public static ArrayNode arr(){return M.createArrayNode();}
 public static String required(JsonNode n,String key){String v=n.path(key).asText("");if(v.isBlank())throw new IllegalArgumentException(key+" is required");return v;}
}
