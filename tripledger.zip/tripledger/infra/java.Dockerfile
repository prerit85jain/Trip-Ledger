FROM maven:3.9.9-eclipse-temurin-17 AS build
WORKDIR /build
COPY pom.xml .
COPY services ./services
ARG SERVICE
RUN mvn -B -pl services/${SERVICE} -am package -DskipTests && cp services/${SERVICE}/target/${SERVICE}-1.0.0.jar /app.jar
FROM eclipse-temurin:17-jre
RUN apt-get update && apt-get install -y --no-install-recommends curl && rm -rf /var/lib/apt/lists/* && groupadd -r app && useradd -r -g app app && mkdir -p /data/receipts && chown -R app:app /data
WORKDIR /app
COPY --from=build /app.jar app.jar
USER app
ENTRYPOINT ["java","-XX:MaxRAMPercentage=70","-jar","app.jar"]
