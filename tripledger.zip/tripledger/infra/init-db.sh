#!/bin/sh
set -eu
for service in identity expense review policy integration; do
  case "$service" in
    identity) password="$IDENTITY_DB_PASSWORD" ;;
    expense) password="$EXPENSE_DB_PASSWORD" ;;
    review) password="$REVIEW_DB_PASSWORD" ;;
    policy) password="$POLICY_DB_PASSWORD" ;;
    integration) password="$INTEGRATION_DB_PASSWORD" ;;
  esac
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres --set service="$service" --set secret="$password" <<'SQL'
CREATE USER :"service" WITH PASSWORD :'secret';
CREATE DATABASE :"service" OWNER :"service";
REVOKE CONNECT ON DATABASE :"service" FROM PUBLIC;
GRANT CONNECT ON DATABASE :"service" TO :"service";
SQL
done
