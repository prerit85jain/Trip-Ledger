# Architecture decisions

1. **Domain ownership.** Identity, expense, review, policy and integration each own their database. Cross-service data travels via APIs or events; no shared tables. Common code contains security, redaction and persistence plumbing only.
2. **Asynchronous reviews.** Expense submission and an outbox row commit together. The publisher marks a row delivered only after a broker confirm. Messages and queues are durable. Duplicate delivery is expected; the immutable revision/run ID and review row lock prevent duplicate final decisions.
3. **Restricted AI boundary.** The model chooses fetch tools and matching candidates. It cannot supply policy values or raw source records to the calculator. AI workers lack backend credentials. The MCP server owns the fetch and compute boundary.
4. **Trusted monetary results.** Calculation output is registered with review-service before decision persistence. Both MCP and review-service reject altered totals/findings/reconciliation. Java's DecisionGate independently enforces escalation and confidence. Prompt compliance alone is not the control.
5. **Runtime policy.** Policy values are versioned data. MCP pins a complete policy snapshot when a run begins; a restart reuses that snapshot. Canonical resources support discovery; run-specific resource templates support reproducibility.
6. **Partial results.** Missing FX produces unavailable totals, not approximations. Missing itinerary, employee data or transaction pages blocks auto-approval. This extends the case study's output shape with `complete` and nullable amounts.
7. **Storage.** PostgreSQL owns business data. Local volumes are an explicit single-machine replacement for planned object storage. SQLite holds MCP context for one MCP replica; horizontal scaling needs an external checkpoint store and per-run coordination.
8. **Human actions.** Reviewers append acceptance/override reasons without rewriting the original decision or issuing payment. A later settlement workflow is a separate concern.
9. **Demo boundaries.** Synthetic JSON receipts and upstream fixtures make the project runnable without paid accounts. Live native tool-calling is configurable, but measured demo quality is never described as measured LLM quality.
10. **Policy ambiguities.** EUR 25 requires a receipt; the auto-approval ceiling is exclusive. Prohibited MCCs hold for audit; other issues require manager review. Multiple financial restrictions on one line use the maximum applicable disallowance, not an additive double deduction.

## State transitions

- Report: `DRAFT -> SUBMITTED`. A submitted report is immutable. A corrected report is a new report in this MVP.
- Run: created as `PROCESSING`, completed after a persisted decision. An exhausted infrastructure job goes to RabbitMQ's dead-letter queue. The UI does not currently surface broker dead-letter reasons; inspect the broker and logs.
- Decision: immutable machine result plus append-only reviewer actions. `review_status` records that a human has reviewed at least one finding, not that payment is approved.

## Extension seams

- Replace integration fixtures with HTTP adapters that preserve the same record contracts.
- Feed authoritative settled lines into review-service's settled read model; do not infer settlement from automatic approval.
- Replace receipt file volume with S3-compatible object storage and short-lived internal access.
- Add an identity provider and asymmetric JWKS verification before public deployment.
- Add an item-level allocation policy for complex overlapping financial restrictions.
- Add real-model evaluations and calibrated confidence thresholds before relying on automatic decisions.
