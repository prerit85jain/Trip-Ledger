"""Offline labelled suite. This measures deterministic tooling, not live LLM quality."""
import json, time
from pathlib import Path
from decimal import Decimal
from .engine import evaluate,outcome

def run(root=None):
    root=Path(root or Path(__file__).resolve().parents[2]/"evals"/"reports")
    results=[];tp=fp=fn=false_approvals=0;money_ok=True
    for path in sorted(root.glob("*.json")):
        fixture=json.loads(path.read_text());expected=set(fixture.pop("expected_rules"));decision=fixture.pop("expected_decision");name=fixture.pop("name");expected_reimbursable=fixture.pop("expected_reimbursable");expected_disallowed=fixture.pop("expected_disallowed")
        start=time.perf_counter();calc=evaluate(**fixture);actual={f["rule_id"] for f in calc["findings"]}
        tp+=len(actual&expected);fp+=len(actual-expected);fn+=len(expected-actual)
        actual_decision=outcome(calc)
        money_ok &= calc["reimbursable_total"]["amount"]==expected_reimbursable and calc["disallowed_total"]["amount"]==expected_disallowed
        if decision!="auto_approve" and actual_decision=="auto_approve":false_approvals+=1
        # Independent Decimal summation, not a call back into compute_totals.
        if calc["reimbursable_total"]["amount"] is not None:
            claim=sum((Decimal(p["claimed"]) for p in calc["per_line"]),Decimal(0))
            reimb=sum((Decimal(p["reimbursable"]) for p in calc["per_line"]),Decimal(0))
            rejected=sum((Decimal(p["disallowed"]) for p in calc["per_line"]),Decimal(0))
            money_ok &= claim==reimb+rejected and reimb==Decimal(calc["reimbursable_total"]["amount"]) and rejected==Decimal(calc["disallowed_total"]["amount"])
        results.append({"name":name,"pass":actual==expected and actual_decision==decision and calc["reimbursable_total"]["amount"]==expected_reimbursable and calc["disallowed_total"]["amount"]==expected_disallowed,"expected":decision,"actual":actual_decision,"expected_rules":sorted(expected),"actual_rules":sorted(actual),"latency_ms":round((time.perf_counter()-start)*1000,3)})
    return {"mode":"offline deterministic tools; no LLM or network","reports":len(results),"passed":sum(r["pass"] for r in results),"precision":tp/(tp+fp) if tp+fp else 1,"recall":tp/(tp+fn) if tp+fn else 1,"false_auto_approvals":false_approvals,"monetary_reconciliation":money_ok,"results":results}

if __name__=="__main__":
    result=run();print(json.dumps(result,indent=2));raise SystemExit(0 if result["passed"]==result["reports"] and result["monetary_reconciliation"] else 1)
