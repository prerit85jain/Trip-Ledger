"""Receipt text is extracted locally so raw image PII never goes to a model API."""
import io, json, re, tempfile, subprocess
from pathlib import Path
from decimal import Decimal
from PIL import Image
import pytesseract
from .privacy import redact

def extract(content,media_type):
    if media_type=="application/json":
        # Synthetic structured receipts are a demo input, not verified real documents.
        value=redact(json.loads(content))
        for field in ("merchant","date","currency","total"):
            if field not in value:raise ValueError("Receipt missing "+field)
        Decimal(str(value["total"]))
        value["confidence"]="0.99"
        value["extraction_method"]="synthetic-json"
        return value
    if media_type=="application/pdf":
        with tempfile.TemporaryDirectory() as directory:
            pdf=Path(directory)/"receipt.pdf";pdf.write_bytes(content)
            subprocess.run(["pdftoppm","-f","1","-singlefile","-scale-to","2000","-png",str(pdf),str(Path(directory)/"page")],check=True,timeout=20,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            with Image.open(Path(directory)/"page.png") as image:text=pytesseract.image_to_string(image,timeout=20)
    else:
        with Image.open(io.BytesIO(content)) as image:
            image.thumbnail((2000,2000));text=pytesseract.image_to_string(image,timeout=20)
    text=redact(text)
    total=re.search(r"(?:grand\s+total|total)\s*[:€$₹]?\s*(\d+[.,]\d{2})",text,re.I)
    day=re.search(r"\b(20\d{2}-\d{2}-\d{2})\b",text)
    currency="EUR" if "EUR" in text or "€" in text else "USD" if "USD" in text or "$" in text else "INR" if "INR" in text or "₹" in text else None
    return {"merchant":next(iter(text.splitlines()),""),"date":day.group(1) if day else None,"currency":currency,"total":total.group(1).replace(",",".") if total else None,"tax":None,"confidence":"0.60","extraction_method":"local-ocr","note":"Conservative OCR; requires human verification"}
