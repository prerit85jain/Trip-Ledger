import asyncio, json, os, time, logging, threading
from concurrent.futures import ThreadPoolExecutor
import pika
from .agent import review

logging.basicConfig(level=logging.INFO,format="%(message)s")

def main():
    executor=ThreadPoolExecutor(max_workers=1)
    while True:
        try:
            connection=pika.BlockingConnection(pika.ConnectionParameters(host=os.getenv("RABBIT_HOST","rabbitmq"),credentials=pika.PlainCredentials(os.getenv("RABBIT_USER","tripledger"),os.environ["RABBIT_PASSWORD"]),heartbeat=60,blocked_connection_timeout=120))
            channel=connection.channel()
            channel.queue_declare(queue="tripledger.dead",durable=True)
            channel.queue_declare(queue="tripledger.reviews",durable=True,arguments={"x-dead-letter-exchange":"","x-dead-letter-routing-key":"tripledger.dead"})
            channel.basic_qos(prefetch_count=1)
            channel.confirm_delivery()
            def consume(ch,method,properties,body):
                def job():
                    try:
                        event=json.loads(body);decision=asyncio.run(review(event))
                        logging.info(json.dumps({"event":"review.completed","run_id":event["run_id"],"decision":decision["decision"]}))
                        connection.add_callback_threadsafe(lambda:ch.basic_ack(method.delivery_tag))
                    except Exception as exc:
                        attempts=int((properties.headers or {}).get("attempts",0))
                        logging.error(json.dumps({"event":"review.failed","code":type(exc).__name__,"attempt":attempts}))
                        def retry():
                            if attempts<2:
                                ch.basic_publish(exchange="",routing_key="tripledger.reviews",body=body,properties=pika.BasicProperties(delivery_mode=2,content_type="application/json",headers={"attempts":attempts+1}))
                                ch.basic_ack(method.delivery_tag)
                            else:ch.basic_nack(method.delivery_tag,requeue=False)
                        time.sleep(min(2**attempts,4))
                        connection.add_callback_threadsafe(retry)
                executor.submit(job)
            channel.basic_consume(queue="tripledger.reviews",on_message_callback=consume)
            logging.info(json.dumps({"event":"worker.ready","mode":os.getenv("AI_MODE","demo")}))
            channel.start_consuming()
        except pika.exceptions.AMQPError:
            logging.warning('{"event":"broker.reconnect"}');time.sleep(5)

if __name__=="__main__":main()
