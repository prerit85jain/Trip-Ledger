import os, time, random, json, sqlite3
from pathlib import Path
import httpx
from .privacy import redact

class Backend:
    """Only the MCP process constructs this client; AI workers have no backend keys."""
    def __init__(self):
        self.client=httpx.Client(timeout=10,headers={"X-Service-Key":os.environ["SERVICE_KEY"]})
        self.urls={name:os.getenv(name.upper()+"_URL",f"http://{name}-service:{port}") for name,port in [("expense",8082),("review",8083),("policy",8084),("integration",8085)]}
    def request(self,service,path,body=None,raw=False):
        for attempt in range(4):
            try:
                response=self.client.request("GET" if body is None else "POST",self.urls[service]+"/internal/"+path,json=body)
                response.raise_for_status()
                return response.content if raw else redact(response.json())
            except (httpx.TimeoutException,httpx.NetworkError,httpx.HTTPStatusError) as exc:
                if isinstance(exc,httpx.HTTPStatusError) and exc.response.status_code not in (429,500,502,503,504):raise
                if attempt==3:raise
                time.sleep(min(2**attempt+random.random(),8))

class ContextStore:
    def __init__(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.path=path
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("CREATE TABLE IF NOT EXISTS contexts (id TEXT PRIMARY KEY, body TEXT NOT NULL)")
    def connect(self):return sqlite3.connect(self.path,timeout=30)
    def get(self,key):
        with self.connect() as db:
            row=db.execute("SELECT body FROM contexts WHERE id=?",(key,)).fetchone()
        return json.loads(row[0]) if row else None
    def put(self,key,value):
        with self.connect() as db:
            db.execute("INSERT INTO contexts VALUES(?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body",(key,json.dumps(redact(value))))
