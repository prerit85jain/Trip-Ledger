"""Private operational API; review jobs enter via RabbitMQ, never public model endpoints."""
import os
from fastapi import FastAPI
app=FastAPI(title="TripLedger AI service",version="1.0.0")
@app.get("/health")
def health():return {"status":"up","mode":os.getenv("AI_MODE","demo")}
