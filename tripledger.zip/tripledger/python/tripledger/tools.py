import os, json, uuid, re
from datetime import date, timedelta
from .backend import Backend, ContextStore
from .engine import candidates, evaluate, money, fmt
from .receipts import extract
from .schemas import Report

class ReviewTools:
    def __init__(self,backend=None,state=None):
        self.backend=backend or Backend()
        self.state=state or ContextStore(os.getenv("CONTEXT_DB","/data/mcp/contexts.db"))
    def context(self,run_id):
        if not re.fullmatch(r"EXP-[a-zA-Z0-9-]+-r1",run_id):raise ValueError("Invalid run ID")
        c=self.state.get(run_id)
        if c:return c
        report_id=run_id[:-3]
        report=self.backend.request("expense",f"reports/{report_id}")
        if report.get("status")!="SUBMITTED" or report.get("run_id")!=run_id:raise ValueError("Report is not submitted")
        Report.model_validate(report)
        policies=self.backend.request("policy","policies")
        submitted=report["submitted_at"][:10]
        applicable=[p for p in policies if p["effective_from"]<=submitted<=p["effective_to"]]
        if not applicable:raise ValueError("No effective policy for report")
        policy=sorted(applicable,key=lambda p:(p["effective_from"],p["version"]),reverse=True)[0]
        c={"run_id":run_id,"report":report,"policy":policy,"transactions":[],"receipts":{},"rates":{},"pages":[],"errors":[],"trace":[]}
        self.backend.request("review","runs",{"run_id":run_id,"report_id":report_id,"employee_id":report["employee_id"],"status":"PROCESSING","policy_version":policy["version"]})
        self.state.put(run_id,c)
        return c
    def execute(self,name,run_id,**args):
        c=self.context(run_id)
        try:
            result=getattr(self,"do_"+name)(c,**args)
            c["trace"].append({"tool":name,"args":args,"result":result})
            self.state.put(run_id,c)
            return {"ok":True,"data":result}
        except Exception as exc:
            # Persist unavailable source information; no exception text with URLs/secrets.
            code=type(exc).__name__
            c["errors"].append({"tool":name,"code":code})
            self.state.put(run_id,c)
            return {"ok":False,"error":{"code":code,"message":f"{name} unavailable or invalid input","retryable":False}}
    def do_get_employee(self,c):
        c["employee"]=self.backend.request("integration",f"employees/{c['report']['employee_id']}");return c["employee"]
    def do_get_trip(self,c):
        c["trip"]=self.backend.request("integration",f"trips/{c['report']['trip_id']}");return c["trip"]
    def do_list_card_transactions(self,c,cursor=0):
        trip=c.get("trip")
        dates=[date.fromisoformat(l["date"]) for l in c["report"]["line_items"]]
        start=date.fromisoformat(trip["start_date"]) if trip else min(dates)
        end=date.fromisoformat(trip["end_date"]) if trip else max(dates)
        start-=timedelta(days=2);end+=timedelta(days=2)
        page=self.backend.request("integration",f"transactions?employee_id={c['report']['employee_id']}&from={start}&to={end}&cursor={cursor}")
        by_id={t["transaction_id"]:t for t in c["transactions"]}
        by_id.update({t["transaction_id"]:t for t in page["items"]});c["transactions"]=list(by_id.values())
        c["pages"]=[p for p in c["pages"] if p["cursor"]!=cursor]+[{"cursor":cursor,"next":page["next_cursor"]}]
        return page
    def do_list_settled_lines(self,c):
        c["settled"]=self.backend.request("review",f"settled-lines?employee_id={c['report']['employee_id']}&months=12");return {"items":c["settled"]}
    def do_read_receipt(self,c,receipt_id):
        if receipt_id not in [l.get("receipt_id") for l in c["report"]["line_items"]]:raise ValueError("Receipt outside report")
        meta=self.backend.request("expense",f"receipts/{receipt_id}")
        if meta["employee_id"]!=c["report"]["employee_id"]:raise ValueError("Receipt outside employee scope")
        content=self.backend.request("expense",f"receipts/{receipt_id}/content",raw=True)
        receipt=extract(content,meta["media_type"]);c["receipts"][receipt_id]=receipt;return receipt
    def do_match_transactions(self,c):
        c["proposals"]=candidates(c["report"]["line_items"],c["transactions"]);return c["proposals"]
    def do_fx_convert(self,c,line_id,transaction_id=None):
        line=next(l for l in c["report"]["line_items"] if l["line_id"]==line_id)
        txn=next((t for t in c["transactions"] if t["transaction_id"]==transaction_id),None)
        if transaction_id and not any(p["line_id"]==line_id and p["transaction_id"]==transaction_id for p in c.get("proposals",{}).get("pairs",[])):raise ValueError("Not a candidate transaction")
        day=txn["date"] if txn else line["date"]
        rate=self.backend.request("integration",f"fx?from={line['currency']}&to=EUR&date={day}")
        c["rates"][f"{line['currency']}:{day}"]=rate
        return {"line_id":line_id,"amount":fmt(money(line["amount"])*money_rate(rate["rate"])),"currency":"EUR",**rate}
    def do_compute_totals(self,c,matches):
        proposals=c.get("proposals",{}).get("pairs",[])
        if len(set(matches.values()))!=len(matches):raise ValueError("One transaction cannot match multiple lines")
        for line_id,txn_id in matches.items():
            if not any(p["line_id"]==line_id and p["transaction_id"]==txn_id for p in proposals):raise ValueError("Match was not proposed by the tool")
        pages={p["cursor"]:p["next"] for p in c["pages"]}
        cursor=0;visited=set();all_pages=False
        while cursor in pages and cursor not in visited:
            visited.add(cursor);cursor=pages[cursor]
            if cursor is None:all_pages=True;break
        gaps=[]
        if not all_pages:gaps.append("Transaction pagination incomplete")
        for required in ("employee","trip","settled"):
            if required not in c:gaps.append(required+" unavailable")
        calc=evaluate(c["report"],c["policy"],c.get("employee"),c.get("trip"),c["transactions"],c["receipts"],c.get("settled",[]),c["rates"],matches,complete=not gaps,gaps=gaps)
        calc.update({"calculation_id":"CALC-"+str(uuid.uuid4()),"run_id":c["run_id"]})
        self.backend.request("review","calculations",calc)
        c["calculation"]=calc
        return calc
    def do_save_decision(self,c,decision):
        calc=c.get("calculation")
        if not calc:raise ValueError("No verified calculation")
        for field in ("reimbursable_total","disallowed_total","findings","reconciliation"):
            if decision.get(field)!=calc[field]:raise ValueError("Unverified "+field)
        if decision.get("calculation_id")!=calc["calculation_id"]:raise ValueError("Stale calculation")
        decision["run_id"]=c["run_id"]
        result=self.backend.request("review","decisions",decision)
        c["decision"]=result
        return result

def money_rate(value):
    from decimal import Decimal
    return Decimal(str(value))
