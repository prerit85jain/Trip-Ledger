from decimal import Decimal
from datetime import date, datetime
from typing import Literal
from pydantic import BaseModel, Field, ConfigDict, field_validator

class Line(BaseModel):
    model_config = ConfigDict(extra="ignore")
    line_id: str = Field(min_length=1, max_length=80)
    date: date
    category: Literal["hotel", "meals", "taxi", "flight", "other"]
    merchant: str = Field(min_length=1, max_length=300)
    amount: Decimal = Field(ge=0, le=1000000, decimal_places=2)
    currency: str = Field(pattern="^[A-Z]{3}$")
    description: str = Field(default="", max_length=2000)
    receipt_id: str | None = None
    nights: int | None = Field(default=None, ge=1, le=365)
    attendees: int | None = Field(default=None, ge=1, le=1000)
    client_dinner: bool = False
    alcohol_amount: Decimal = Field(default=Decimal("0"), ge=0)
    cabin: str = "economy"
    flight_hours: Decimal | None = Field(default=None, ge=0)

class Report(BaseModel):
    report_id: str
    employee_id: str
    trip_id: str
    submitted_at: datetime
    base_currency: Literal["EUR"] = "EUR"
    line_items: list[Line] = Field(min_length=1, max_length=100)

    @field_validator("line_items")
    @classmethod
    def unique_ids(cls, lines):
        if len({line.line_id for line in lines}) != len(lines):
            raise ValueError("Duplicate line IDs")
        return lines
