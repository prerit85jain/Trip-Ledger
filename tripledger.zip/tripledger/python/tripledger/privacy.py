import re

def redact(value):
    if isinstance(value, dict):
        return {k: redact(v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value]
    if not isinstance(value, str):
        return value
    if re.fullmatch(r"-?\d+\.\d+", value):
        return value
    value = re.sub(r"(?<![A-Za-z0-9-])(?:\d[ -]?){9,15}(\d{4})(?![A-Za-z0-9-])", r"****\1", value)
    value = re.sub(r"[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}", "[email redacted]", value)
    value = re.sub(r"(?<![A-Za-z0-9-])\+?\d[\d ()-]{8,}\d(?![A-Za-z0-9-])", lambda m: m.group(0) if re.fullmatch(r"20\d{2}-\d{2}-\d{2}", m.group(0)) else "[phone redacted]", value)
    return value
