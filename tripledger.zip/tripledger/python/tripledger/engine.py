"""Pure deterministic policy evaluation. No network, model, or binary floats for money."""
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
from difflib import SequenceMatcher
import re
from .schemas import Report

D = Decimal
CENT = D("0.01")

def money(value):
    return D(str(value)).quantize(CENT, rounding=ROUND_HALF_UP)

def fmt(value):
    return format(money(value), ".2f")

def merchant(value):
    value = re.sub(r"[^a-z0-9 ]", " ", value.lower())
    if "uber" in value:
        return "uber"
    return " ".join(value.split())

def candidates(lines, transactions):
    pairs = []
    for line in lines:
        for txn in transactions:
            if line["currency"] != txn["currency"]:
                continue
            days = abs((date.fromisoformat(str(line["date"])) - date.fromisoformat(txn["date"])).days)
            if days > 2:
                continue
            similarity = SequenceMatcher(None, merchant(line["merchant"]), merchant(txn["merchant"])).ratio()
            delta = abs(money(line["amount"]) - money(txn["amount"]))
            if similarity < 0.55:
                continue
            amount_score = D("1") if delta == 0 else max(D("0"), D("1") - delta / max(money(line["amount"]), D("1")))
            score = D(str(similarity)) * D("0.55") + amount_score * D("0.35") + (D("1") - D(days) / D("3")) * D("0.10")
            if score >= D("0.70"):
                pairs.append({"line_id": line["line_id"], "transaction_id": txn["transaction_id"], "score": str(score.quantize(D("0.001"))), "delta": fmt(delta), "reasons": ["merchant similarity", "date proximity", "amount proximity"]})
    pairs.sort(key=lambda p: D(p["score"]), reverse=True)
    return {"pairs": pairs, "unmatched_lines": [l["line_id"] for l in lines if not any(p["line_id"] == l["line_id"] for p in pairs)]}

def select_matches(proposals):
    selected, used = {}, set()
    for p in proposals["pairs"]:
        if p["line_id"] not in selected and p["transaction_id"] not in used and D(p["score"]) >= D("0.85"):
            selected[p["line_id"]] = p["transaction_id"]
            used.add(p["transaction_id"])
    return selected

def evaluate(report, policy, employee, trip, transactions, receipts, settled, rates, matches, complete=True, gaps=None):
    """Returns authoritative figures and findings; all inputs are trusted fetched snapshots.

    rates keys are '<currency>:<transaction-date>' to EUR. Receipts and report text
    remain untrusted assertions, checked against card/travel facts.
    """
    report = Report.model_validate(report).model_dump(mode="json")
    lines = report["line_items"]
    findings, reconciled, breakdown = [], [], []
    gaps = list(gaps or [])
    disallow = {l["line_id"]: D("0") for l in lines}
    converted, txn_by_id = {}, {t["transaction_id"]: t for t in transactions}
    seen, used_txns, meal_groups = set(), {}, {}
    audit = False
    def add(rule, line, observed, permitted, excess=None, refs=None, severity=None):
        findings.append({"finding_id": f"F-{len(findings)+1:03}", "rule_id": rule, "severity": severity or policy.get("rules", {}).get(rule, {}).get("severity", "query"), "line_id": line, "observed": str(observed), "permitted": str(permitted), "excess": None if excess is None else fmt(excess), "evidence": (refs or []) + [{"source": "resource", "ref": f"tripledger://policy/expense-policy@{policy['version']}#{rule}"}]})
    for gap in gaps:
        add("DATA", None, gap, "Complete source data required", severity="query")
    if not complete and not gaps:
        add("DATA", None, "Incomplete source data", "Complete source data required", severity="query")
    if trip and trip.get("employee_id") != report["employee_id"]:
        add("DATA", None, "Trip does not belong to employee", "Employee-owned itinerary", severity="query")
        complete = False
    for line in lines:
        lid, original = line["line_id"], money(line["amount"])
        txn = txn_by_id.get(matches.get(lid, ""))
        txdate = txn["date"] if txn else line["date"]
        rate = {"rate": "1", "rate_date": txdate, "source": "identity"} if line["currency"] == "EUR" else rates.get(f"{line['currency']}:{txdate}")
        if rate is None:
            complete = False
            add("FX", lid, "Historical rate unavailable", "Dated conversion evidence", severity="query")
            converted[lid] = None
        else:
            converted[lid] = money(original * D(rate["rate"]))
        amount = converted[lid]
        refs = [{"source": "report", "ref": report["report_id"]+"#"+lid}]
        status = "matched"
        if txn:
            refs.append({"source": "list_card_transactions", "ref": txn["transaction_id"]})
            if txn["transaction_id"] in used_txns:
                add("MATCH", lid, "Transaction reused", "One transaction per claim", refs=refs, severity="query")
                complete = False
            used_txns[txn["transaction_id"]] = lid
            delta = money(original - money(txn["amount"]))
            if txn["currency"] != line["currency"] or delta != 0:
                status = "amount_mismatch"
                add("MATCH", lid, f"Claim {original} {line['currency']}; card {txn['amount']} {txn['currency']}", "Matching card amount and currency", refs=refs, severity="query")
        else:
            delta = None
            status = "missing_transaction"
            add("MATCH", lid, "No verified transaction match", "A fetched card transaction", refs=refs, severity="query")
        receipt = receipts.get(line.get("receipt_id"))
        receipt_ok = receipt is not None and D(str(receipt.get("confidence", 0))) >= D("0.85")
        if amount is not None and amount >= D(policy["receipt_threshold"]) and not receipt_ok:
            status = "missing_receipt"
            add("R-02", lid, "Receipt missing or unreadable", f"Itemised receipt for EUR {policy['receipt_threshold']} or more", refs=refs)
        if receipt_ok:
            refs.append({"source": "read_receipt", "ref": line["receipt_id"]})
            if money(receipt["total"]) != original or receipt["currency"] != line["currency"] or receipt["date"] != line["date"] or SequenceMatcher(None,merchant(receipt["merchant"]),merchant(line["merchant"])).ratio()<0.55:
                status = "amount_mismatch"
                add("RECEIPT", lid, "Receipt fields disagree with claim", "Consistent merchant, date, currency and total", refs=refs, severity="query")
        if trip:
            when = date.fromisoformat(line["date"])
            margin = timedelta(days=int(policy["trip_margin_days"]))
            if not date.fromisoformat(trip["start_date"])-margin <= when <= date.fromisoformat(trip["end_date"])+margin:
                status = "outside_trip_dates"
                add("R-01", lid, line["date"], f"{trip['start_date']} to {trip['end_date']} plus permitted travel margin", refs=refs+[{"source":"get_trip","ref":trip["trip_id"]}])
        else:
            complete = False
            add("R-01", lid, "Itinerary unavailable", "Verified trip dates", refs=refs)
        fingerprint = (merchant(line["merchant"]), line["date"], original, line["currency"])
        cutoff = date.fromisoformat(report["submitted_at"][:10])-timedelta(days=366)
        prior = [s for s in settled if date.fromisoformat(s.get("settled_at",s["date"])[:10])>=cutoff and (merchant(s["merchant"]), s["date"], money(s["amount"]), s["currency"]) == fingerprint]
        if fingerprint in seen or prior:
            status = "duplicate"
            add("R-08", lid, "Repeated merchant/date/amount/currency", "No duplicate claims", amount, refs+[{"source":"list_settled_lines","ref":s.get("line_id","prior")} for s in prior])
            if amount is not None: disallow[lid] = amount
        seen.add(fingerprint)
        caps = policy["per_diem"].get(trip.get("city") if trip else "")
        if line["category"] in ("hotel","meals") and caps is None:
            complete=False
            add("DATA",lid,"City cap unavailable","Configured city cap",refs=refs,severity="query")
        if line["category"] == "hotel" and caps and amount is not None:
            nights = line.get("nights")
            if not nights or not trip or nights > trip.get("hotel_nights", 0):
                add("R-03", lid, "Night count missing or inconsistent", "Night count within itinerary", refs=refs, severity="query")
            else:
                cap = D(caps["hotel"])*D(nights)
                if amount > cap:
                    excess=amount-cap;disallow[lid]=max(disallow[lid],excess)
                    add("R-03",lid,fmt(amount),fmt(cap),excess,refs)
        if line["category"] == "meals" and caps and amount is not None:
            heads=line.get("attendees") or (None if line["client_dinner"] else 1)
            if not heads:
                add("R-04",lid,"Client attendee count missing","Positive attendee count",refs=refs)
            else:
                key=(line["date"],bool(line["client_dinner"]))
                meal_groups.setdefault(key,[]).append((line,amount,heads,refs))
        if line["category"] == "flight" and line.get("cabin","economy").lower() not in ("economy","standard"):
            flights=trip.get("flights",[]) if trip else []
            # Submitted duration cannot grant an exception; use booked itinerary.
            qualifies=any(D(str(f.get("duration_hours",0)))>D(policy["premium_min_hours"]) and f.get("cabin","").lower()==line["cabin"].lower() for f in flights)
            if not employee or (employee.get("grade") not in policy["premium_grades"] and not qualifies):
                add("R-05",lid,"Premium cabin without verified exception","Eligible grade or booked segment over policy duration",amount,refs)
                if amount is not None: disallow[lid]=amount
        if D(line["alcohol_amount"])>0 and rate and amount is not None:
            alcohol=money(D(line["alcohol_amount"])*D(rate["rate"]))
            allowed=money(amount*D(policy["alcohol_fraction"])) if line["client_dinner"] else D("0")
            if alcohol>allowed:
                excess=min(amount,alcohol-allowed);disallow[lid]=max(disallow[lid],excess)
                add("R-06",lid,fmt(alcohol),fmt(allowed),excess,refs)
        if txn and policy["mcc"].get(txn.get("mcc"),{}).get("prohibited"):
            audit=True
            add("R-07",lid,txn["mcc"],"Permitted merchant category",amount,refs)
            if amount is not None: disallow[lid]=amount
        if re.search(r"ignore (?:all |the )?(?:policy|rules|instructions)|approved by (?:cfo|ceo)|system prompt",line["description"],re.I):
            add("INJECTION",lid,"Instruction-like text ignored","Expense descriptions are data",refs=refs,severity="advisory")
        reconciled.append({"line_id":lid,"status":status,"transaction_id":txn["transaction_id"] if txn else None,"delta":None if delta is None else fmt(delta)})
    # Daily per-head spend is aggregated, rather than applying the entire daily cap per receipt.
    for (_,client),items in meal_groups.items():
        cap=D(policy["per_diem"][trip["city"]]["client_dinner" if client else "meal"])
        remaining=cap
        for line,amount,heads,refs in items:
            per_head=amount/D(heads)
            excess_per_head=max(D("0"),per_head-remaining)
            remaining=max(D("0"),remaining-per_head)
            if excess_per_head>0:
                excess=min(amount,money(excess_per_head*D(heads)))
                disallow[line["line_id"]]=max(disallow[line["line_id"]],excess)
                add("R-04",line["line_id"],fmt(per_head),f"EUR {fmt(cap)} per head per day",excess,refs)
    if trip and (date.fromisoformat(report["submitted_at"][:10])-date.fromisoformat(trip["end_date"])).days>int(policy["late_days"]):
        add("R-09",None,report["submitted_at"][:10],f"Within {policy['late_days']} days after trip",refs=[{"source":"get_trip","ref":trip["trip_id"]}])
    for line in lines:
        lid=line["line_id"];a=converted[lid]
        rejected=None if a is None else min(a,disallow[lid])
        breakdown.append({"line_id":lid,"claimed":None if a is None else fmt(a),"reimbursable":None if a is None else fmt(a-rejected),"disallowed":None if a is None else fmt(rejected)})
    available=all(v is not None for v in converted.values())
    total=sum((D(b["reimbursable"]) for b in breakdown),D("0")) if available else None
    rejected=sum((D(b["disallowed"]) for b in breakdown),D("0")) if available else None
    if total is not None and total>=D(policy["auto_approval_ceiling"]):
        add("R-10",None,fmt(total),f"Below EUR {policy['auto_approval_ceiling']}",severity="advisory")
    return {"policy_version":policy["version"],"complete":bool(complete and available),"confidence_cap":"0.95" if complete and available else "0.50","confidence_threshold":policy["confidence_threshold"],"auto_approval_ceiling":policy["auto_approval_ceiling"],"audit_required":audit,"reimbursable_total":{"amount":fmt(total) if total is not None else None,"currency":"EUR"},"disallowed_total":{"amount":fmt(rejected) if rejected is not None else None,"currency":"EUR"},"per_line":breakdown,"findings":findings,"reconciliation":reconciled,"fx_evidence":rates}

def outcome(calc, confidence="0.90"):
    if calc["audit_required"]: return "audit_hold"
    unresolved=any(f["severity"] in ("query","blocking") or f["rule_id"] in ("R-02","R-07","R-08") for f in calc["findings"])
    if calc["complete"] and not unresolved and min(D(str(confidence)),D(calc["confidence_cap"]))>=D(calc["confidence_threshold"]) and D(calc["reimbursable_total"]["amount"])<D(calc["auto_approval_ceiling"]):return "auto_approve"
    return "manager_review"
