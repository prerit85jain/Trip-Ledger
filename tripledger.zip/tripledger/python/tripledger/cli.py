"""Submit one report or a directory; invalid inputs never abort later files."""
import argparse,json,os,getpass
from pathlib import Path
import httpx

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('input',type=Path,help='Report JSON file or directory of report JSON files')
    parser.add_argument('--url',default='http://localhost:3000')
    parser.add_argument('--username',default='employee')
    args=parser.parse_args()
    password=os.getenv('DEMO_PASSWORD') or getpass.getpass('Demo password: ')
    with httpx.Client(base_url=args.url,timeout=30) as client:
        response=client.post('/api/auth/login',json={'username':args.username,'password':password});response.raise_for_status()
        client.headers['Authorization']='Bearer '+response.json()['access_token']
        files=sorted(args.input.glob('*.json')) if args.input.is_dir() else [args.input]
        failures=0
        for file in files:
            try:
                report=json.loads(file.read_text())
                for line in report['line_items']:
                    receipt=line.pop('receipt_file',None)
                    if receipt:
                        path=(file.parent/receipt).resolve()
                        if not path.is_relative_to(file.parent.resolve()):raise ValueError('Receipt outside report directory')
                        with path.open('rb') as stream:
                            r=client.post('/api/receipts',files={'file':(path.name,stream,'application/json' if path.suffix=='.json' else 'application/pdf' if path.suffix=='.pdf' else 'image/png' if path.suffix=='.png' else 'image/jpeg')});r.raise_for_status()
                            line['receipt_id']=r.json()['receipt_id']
                r=client.post('/api/reports',json=report);r.raise_for_status();data=r.json()
                r=client.post('/api/reports/'+data['report_id']+'/submit');r.raise_for_status()
                print(json.dumps({'file':file.name,'status':'submitted','report_id':data['report_id'],'run_id':r.json()['run_id']}))
            except (ValueError,KeyError,OSError,httpx.HTTPError) as exc:
                failures+=1;print(json.dumps({'file':file.name,'status':'invalid_or_unavailable','error':type(exc).__name__}))
        raise SystemExit(1 if failures else 0)
if __name__=='__main__':main()
