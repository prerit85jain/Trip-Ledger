"""Provider boundary: OpenAI-compatible tool-calling HTTP API, configurable model/base URL."""
import os, json, asyncio
import httpx

class ModelClient:
    def __init__(self):
        self.model=os.environ["MODEL_NAME"]
        self.key=os.environ["MODEL_API_KEY"]
        self.url=os.getenv("MODEL_BASE_URL","https://generativelanguage.googleapis.com/v1beta/openai").rstrip("/")+"/chat/completions"
    async def complete(self,messages,tools):
        payload={"model":self.model,"messages":messages,"tools":tools,"temperature":0.1}
        async with httpx.AsyncClient(timeout=45) as client:
            for attempt in range(4):
                try:
                    r=await client.post(self.url,headers={"Authorization":"Bearer "+self.key},json=payload)
                    r.raise_for_status();value=r.json()
                    return value["choices"][0]["message"],value.get("usage",{})
                except (httpx.TimeoutException,httpx.NetworkError,httpx.HTTPStatusError) as exc:
                    if isinstance(exc,httpx.HTTPStatusError) and exc.response.status_code not in (429,500,502,503,504):raise
                    if attempt==3:raise
                    await asyncio.sleep(2**attempt)
