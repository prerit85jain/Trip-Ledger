import copy,json
from pathlib import Path
from decimal import Decimal
import pytest
from tripledger.engine import evaluate,outcome,candidates,select_matches
from tripledger.privacy import redact
from tripledger.evals import run
ROOT=Path(__file__).resolve().parents[2]

def load(name):
    file=next((ROOT/"evals/reports").glob("*"+name+".json"));c=json.loads(file.read_text())
    for key in ("name","expected_rules","expected_decision","expected_reimbursable","expected_disallowed"):c.pop(key)
    return c

def test_all_labelled_reports():
    result=run();assert result['passed']==25,result;assert result['monetary_reconciliation']

def test_hotel_disallows_only_excess():
    c=evaluate(**load('hotel-excess-600.00'))
    assert c['reimbursable_total']['amount']=='450.00'
    assert c['disallowed_total']['amount']=='150.00'

def test_prohibited_line_disallowed_once_even_with_alcohol():
    c=load('prohibited-7995');c['report']['line_items'][0]['alcohol_amount']='10.00'
    result=evaluate(**c)
    assert result['disallowed_total']['amount']=='18.00'
    assert result['reimbursable_total']['amount']=='0.00'

def test_missing_rate_never_zero():
    c=evaluate(**load('fx-unavailable'))
    assert c['reimbursable_total']['amount'] is None
    assert outcome(c)=='manager_review'

def test_pagination_prevents_approval():
    assert outcome(evaluate(**load('pagination-incomplete')))=='manager_review'

def test_daily_meals_aggregate():
    c=load('clean-1');l=c['report']['line_items'][0];l.update(category='meals',amount='24.00')
    c['transactions'][0]['amount']='24.00'
    c['report']['line_items'].append({**l,'line_id':'L2','merchant':'Other restaurant'})
    c['transactions'].append({**c['transactions'][0],'transaction_id':'T2','merchant':'Other restaurant'})
    c['matches']['L2']='T2'
    result=evaluate(**c)
    assert result['disallowed_total']['amount']=='8.00'
    assert any(f['rule_id']=='R-04' for f in result['findings'])

def test_claimed_long_flight_cannot_grant_exception():
    c=load('premium-cabin');assert outcome(evaluate(**c))=='manager_review'
    c['trip']['flights']=[{'duration_hours':'7','cabin':'business'}]
    assert outcome(evaluate(**c))=='auto_approve'

def test_historical_conversion_exact():
    c=load('fx-unavailable');c['rates']={'USD:2026-10-02':{'rate':'0.909090909091','rate_date':'2026-10-02','source':'test'}}
    result=evaluate(**c);assert result['reimbursable_total']['amount']=='16.36'

def test_redaction_preserves_dates_and_masks_contacts():
    assert redact('2026-10-02')=='2026-10-02'
    assert redact('2026-10-03T12:00:00Z')=='2026-10-03T12:00:00Z'
    # Construct synthetic patterns only inside test memory.
    assert redact('4'*12+'1234')=='****1234'
    assert 'example.test' not in redact('person@example.test')
    assert '1234567890' not in redact('1234567890')

def test_merchant_normalization():
    c=load('clean-1');c['report']['line_items'][0]['merchant']='UBER *TRIP HELP.UBER.CO';c['transactions'][0]['merchant']='UBER BV AMSTERDAM'
    assert select_matches(candidates(c['report']['line_items'],c['transactions']))=={'L1':'T1'}

def test_duplicate_is_currency_sensitive():
    c=load('cross-report-duplicate');c['settled'][0]['currency']='USD'
    assert not any(f['rule_id']=='R-08' for f in evaluate(**c)['findings'])

def test_receipt_boundary():
    c=evaluate(**load('missing-receipt-25.00'))
    assert any(f['rule_id']=='R-02' for f in c['findings'])

def test_repeat_run_identical():
    fixture=load('meal-cap-50.00');assert evaluate(**fixture)==evaluate(**fixture)

def test_redaction_preserves_exact_rate():
    assert redact("0.909090909091")=="0.909090909091"

def test_redaction_preserves_machine_ids():
    identifier="RCT-12345678-1234-1234-abcd-123456789abc"
    assert redact(identifier)==identifier
