import json
from pathlib import Path
import pytest
from tripledger.tools import ReviewTools
from tripledger.backend import ContextStore
ROOT=Path(__file__).resolve().parents[2]
class FakeBackend:
    def __init__(self):
        self.fixture=json.loads(next((ROOT/'evals/reports').glob('*clean-1.json')).read_text());self.calls=[];self.calc=None
    def request(self,service,path,body=None,raw=False):
        self.calls.append((service,path))
        f=self.fixture
        if service=='expense':return {**f['report'],'status':'SUBMITTED','run_id':'EXP-eval-r1'}
        if service=='policy':return [f['policy']]
        if path=='runs':return body
        if path.startswith('employees/'):return f['employee']
        if path.startswith('trips/'):return f['trip']
        if path.startswith('transactions?'):return {'items':f['transactions'],'next_cursor':20 if path.endswith('cursor=0') else None}
        if path.startswith('settled-lines'):return []
        if path=='calculations':self.calc=body;return body
        if path=='decisions':return body
        raise AssertionError(path)

def ready(tmp_path,paginate=True):
    backend=FakeBackend();tools=ReviewTools(backend,ContextStore(str(tmp_path/'state.db')))
    for name in ['get_trip','get_employee','list_settled_lines','list_card_transactions']:
        assert tools.execute(name,'EXP-eval-r1')['ok']
    if paginate:tools.execute('list_card_transactions','EXP-eval-r1',cursor=20)
    tools.execute('match_transactions','EXP-eval-r1')
    return tools,backend

def test_partial_pages_cannot_approve(tmp_path):
    tools,_=ready(tmp_path,False);r=tools.execute('compute_totals','EXP-eval-r1',matches={'L1':'T1'})
    assert r['ok'] and not r['data']['complete']

def test_invented_match_rejected(tmp_path):
    tools,_=ready(tmp_path);assert not tools.execute('compute_totals','EXP-eval-r1',matches={'L1':'fabricated'})['ok']

def test_tampered_total_rejected(tmp_path):
    tools,_=ready(tmp_path);calc=tools.execute('compute_totals','EXP-eval-r1',matches={'L1':'T1'})['data']
    calc['reimbursable_total']['amount']='999.00'
    assert not tools.execute('save_decision','EXP-eval-r1',decision=calc)['ok']

def test_no_arbitrary_receipt(tmp_path):
    tools,_=ready(tmp_path);assert not tools.execute('read_receipt','EXP-eval-r1',receipt_id='../../private')['ok']

def test_policy_pinned_on_resume(tmp_path):
    tools,backend=ready(tmp_path);backend.fixture['policy']['version']='changed'
    assert tools.context('EXP-eval-r1')['policy']['version']=='2026-Q2'
