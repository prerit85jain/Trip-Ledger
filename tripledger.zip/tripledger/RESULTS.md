# Verification results

Verified on 3 October 2026. These results distinguish executable integration checks from offline rule evaluation and untested deployment paths.

## Completed checks

| Check | Result |
|---|---|
| Maven clean verify, JDK 17 | Passed across all seven Maven modules |
| Java unit tests | 10 passed: redaction, decision gate and tampered-total rejection |
| Python regression tests | 20 passed |
| Labelled offline reports | 25/25 expected decisions and rule sets matched |
| Offline finding precision / recall | 100% / 100% on the included synthetic labelled suite |
| False auto-approvals | 0 on that offline suite |
| Monetary checks | All expected totals and accounting identities matched |
| React TypeScript + Vite production build | Passed |
| Real PostgreSQL service startup | All five business services passed health checks |
| Gateway authentication | Unauthenticated report access returned 401 |
| Internal endpoint protection | Missing service key returned 401 |
| MCP discovery | 9 tools, 3 resources, 3 run-pinned resource templates, 1 prompt |
| Real HTTP + MCP review flow | Three complete scenarios passed |
| Re-delivery | Repeated review of each run returned the same decision ID |
| Role enforcement | Employee finding override rejected with 403; reviewer action accepted |
| Audit trail | Decision and reviewer actions persisted |
| Browser | Sign-in, actual API-backed report creation, receipt attachment, desktop and mobile checks passed |

End-to-end expected results:

| Scenario | Outcome | Reimbursable | Disallowed |
|---|---|---:|---:|
| Clean hotel, three nights | auto_approve | EUR 420.00 | EUR 0.00 |
| Hotel exceeds city cap | manager_review | EUR 450.00 | EUR 150.00 |
| Prohibited merchant | audit_hold | EUR 0.00 | EUR 100.00 |

Raw results: `evals/results.json`, `evals/runtime-results.json`. Screenshots: `docs/dashboard.png` and `docs/mobile.png`. Example runtime traces are under `examples/traces/`.

## Verification boundaries

- Docker was unavailable in the build environment. The Java services, gateway, Python MCP server and browser were run directly against a temporary PostgreSQL 16.4 instance. The included Docker Compose YAML was inspected, but container image builds and Compose startup were not executed here.
- The end-to-end test called the AI review worker function directly after submission. The transactional outbox was persisted, but a real RabbitMQ broker was not exercised. Broker delivery, publisher confirms, consumer acknowledgements and dead-letter behavior need a local Compose smoke test.
- No live LLM or live FX API was called. Demo integration results do not establish model accuracy, cost, provider compatibility, confidence calibration or production latency.
- The 25-report evaluation runs deterministic tooling with labelled source data. Its precision/recall numbers are not a generalization claim or live-agent benchmark. Expected monetary totals are separately labelled, with independent Decimal accounting checks.
- The standard sample receipts are synthetic JSON. The local OCR path is conservative and its image recognition accuracy has not been benchmarked. Low confidence forces manual review.
- The original end-to-end 35s/75s performance targets, 15,000-token target under real models, batch provider limits and two-run live decision stability were not measured.
- There was no pre-existing Git history to scan. Generated credentials and temporary test runtime data are excluded from the source archive. No real employee or banking data was used.

## Reproduce

From the project root:

```sh
mvn clean verify
pip install -e "./python[test]"
pytest python/tests -q
python -m tripledger.evals
cd web
npm ci
npm run build
```

For deployment verification, follow README setup, submit the three demo reports, and inspect `docker compose logs -f ai-worker`. The queue should eventually drain and the expected outcomes above should appear in the UI.
